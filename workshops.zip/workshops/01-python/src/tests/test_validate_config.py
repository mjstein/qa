import unittest


class TestValidateConfig(unittest.TestCase):
    """Unit tests to ensure validate_config works correctly"""

    # TODO fill in unit tests

    def test_standard_validation(self):
        raise NotImplementedError

    def test_missing_fields_validation(self):
        raise NotImplementedError

    def test_wrong_temperature_units_validation(self):
        raise NotImplementedError


if __name__ == '__main__':
    unittest.main()
