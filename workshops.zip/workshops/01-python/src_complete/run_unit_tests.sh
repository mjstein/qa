#!/bin/bash
pipenv run python -m unittest discover -s tests -v
